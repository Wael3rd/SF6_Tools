-- =========================================================
-- TrainingGameplayStats_v1.0.lua
-- Passive gameplay counter: PP, WP, HC, AA for P1 & P2
-- Independent script with D2D overlay
-- =========================================================

local re = re
local sdk = sdk
local imgui = imgui

-- =========================================================
-- CONFIGURATION
-- =========================================================
local cfg = {
    visible = true,
    panel_alpha = 0xCC,     -- transparence du fond (0-255)
    panel_width_pct = 0.13, -- largeur panneau (% ecran)
    panel_margin_pct = 0.02, -- marge depuis le bord
    panel_y_pct = 0.28,     -- position verticale (sous les barres de vie)
    pp_postguard_mode = false, -- true = PostGuard detection (trade_dm only), false = custom (trade_dm + dmg=34 + hs!=0)
    debug_training = false, -- force show in training mode
}

-- =========================================================
-- REPLAY DETECTION
-- =========================================================
local is_in_replay = false

pcall(function()
    -- Detect replay start: mInputType == 3 in emote flow setup
    local t_emote = sdk.find_type_definition("app.esports.bBattleFighterEmoteFlow")
    if t_emote then
        local m_setup = t_emote:get_method("setup")
        if m_setup then
            sdk.hook(m_setup, function(args)
                local obj = sdk.to_managed_object(args[2])
                if obj and obj.mInputType == 3 then
                    is_in_replay = true
                    _G.IsInReplay = true
                    _G._replay_stats_reset_pending = true
                end
            end, function(r) return r end)
        end
    end
    -- Detect replay end
    local t_flow = sdk.find_type_definition("app.battle.bBattleFlow")
    if t_flow then
        local m_end = t_flow:get_method("endReplay")
        if m_end then
            sdk.hook(m_end, function(args)
                is_in_replay = false
                _G.IsInReplay = false
            end, function(r) return r end)
        end
    end
end)

local function should_show()
    if not cfg.visible then return false end
    if is_in_replay then return true end
    if _G.IsInBattleHub then return true end
    if cfg.debug_training then return true end
    return false
end

-- =========================================================
-- COLORS (ABGR)
-- =========================================================
local COL = {
    bg        = 0xCC141414,
    border    = 0xFF555555,
    header_bg = 0x33FFFFFF,
    header_p1 = 0xFFFFAA44, -- bleu/cyan
    header_p2 = 0xFF4444FF, -- rouge
    shadow    = 0xFF000000,
    text      = 0xFFDADADA,
    text_dim  = 0xFF888888,
    separator = 0xFF444444,
    pp        = 0xFF4488FF, -- bleu
    wp        = 0xFFFF8800, -- orange
    hc        = 0xFFFFDD00, -- jaune
    aa        = 0xFF00DD00, -- vert
    total     = 0xFFFFFFFF, -- blanc
}

-- =========================================================
-- HC ENGINE: CONFIG + HELPERS (same as HitConfirm training)
-- =========================================================
local hc_config_file = "TrainingHitConfirm_Config.json"

local function parse_list(str)
    local t = {}
    if not str then return t end
    for s in string.gmatch(str, "([^,]+)") do local n = tonumber(s); if n then table.insert(t, n) end end
    return t
end

local function is_in(tbl, val)
    for _, v in ipairs(tbl) do if v == val then return true end end
    return false
end

-- Load HC config from shared config file, with defaults
local hc_cfg = {
    str_trigger_list = "13",
    str_success_list = "13",
    str_break_list = "7,2,1",
    str_dmg_hit_list = "3",
    str_dmg_block_list = "30",
    str_light_btn_list = "16,128",
    dont_count_blocked = true,
}
pcall(function()
    local f = io.open("reframework/data/" .. hc_config_file, "r")
    if not f then return end
    local raw = f:read("*a"); f:close()
    local data = json.load_string(raw)
    if data and data.user then
        local u = data.user
        if u.str_trigger_list then hc_cfg.str_trigger_list = u.str_trigger_list end
        if u.str_success_list then hc_cfg.str_success_list = u.str_success_list end
        if u.str_break_list then hc_cfg.str_break_list = u.str_break_list end
        if u.str_dmg_hit_list then hc_cfg.str_dmg_hit_list = u.str_dmg_hit_list end
        if u.str_dmg_block_list then hc_cfg.str_dmg_block_list = u.str_dmg_block_list end
        if u.str_light_btn_list then hc_cfg.str_light_btn_list = u.str_light_btn_list end
        if u.dont_count_blocked ~= nil then hc_cfg.dont_count_blocked = u.dont_count_blocked end
    end
end)

-- Work tables (parsed from config)
local hc_work = {
    trigger    = parse_list(hc_cfg.str_trigger_list),
    success    = parse_list(hc_cfg.str_success_list),
    break_list = parse_list(hc_cfg.str_break_list),
    dmg_hit    = parse_list(hc_cfg.str_dmg_hit_list),
    dmg_block  = parse_list(hc_cfg.str_dmg_block_list),
    light_btns = parse_list(hc_cfg.str_light_btn_list),
}

local MASK_LIGHT  = 144  -- LP(16) + LK(128)
local MASK_MEDIUM = 288
local MASK_HEAVY  = 576

-- HC detection state per player
local hc_state = {
    [0] = {
        monitor = { active = false, type = nil, has_reset_hs = false, target_combo = 0, is_medium = false },
        lockout = false,
        last_light_time = 0, last_medium_time = 0, last_heavy_time = 0,
    },
    [1] = {
        monitor = { active = false, type = nil, has_reset_hs = false, target_combo = 0, is_medium = false },
        lockout = false,
        last_light_time = 0, last_medium_time = 0, last_heavy_time = 0,
    },
}

-- =========================================================
-- ORANGE ZONE: edge-to-edge distance check (from ZoneChecker)
-- =========================================================
local esf_names_map = {
    ["ESF_001"]="Ryu",     ["ESF_002"]="Luke",    ["ESF_003"]="Kimberly", ["ESF_004"]="Chun-Li",
    ["ESF_005"]="Manon",   ["ESF_006"]="Zangief", ["ESF_007"]="JP",       ["ESF_008"]="Dhalsim",
    ["ESF_009"]="Cammy",   ["ESF_010"]="Ken",     ["ESF_011"]="Dee Jay",  ["ESF_012"]="Lily",
    ["ESF_013"]="A.K.I.",  ["ESF_014"]="Rashid",  ["ESF_015"]="Blanka",   ["ESF_016"]="Juri",
    ["ESF_017"]="Marisa",  ["ESF_018"]="Guile",   ["ESF_019"]="Ed",
    ["ESF_020"]="E. Honda",["ESF_021"]="Jamie",   ["ESF_022"]="Akuma",
    ["ESF_025"]="Sagat",   ["ESF_026"]="M.Bison", ["ESF_027"]="Terry",
    ["ESF_028"]="Maï",     ["ESF_029"]="Elena",   ["ESF_030"]="Viper",["ESF_031"]="Alex"
}

local wp_char_names = { [0] = "?", [1] = "?" }
local _uf_gs = json.load_file("SF6Distance_Data_Attacks.json")
local wp_attack_data = (_uf_gs and _uf_gs.attacks) or json.load_file("SF6DistanceLogger_Data_Attacks.json") or {}
_uf_gs = nil
local function get_viewer_prefs()
    local p = _G.DV_AdvancedPrefs
    if p then return p end
    return { [0] = {}, [1] = {} }
end

-- =========================================================
-- WP MOVE FILTER: per-player exclusion sets (default = all tracked)
-- =========================================================
local WP_CONFIG_FILE = "TrainingGameplayStats_WPFilter.json"
-- wp_excluded[0] = P1's filter (which P2 moves to ignore)
-- wp_excluded[1] = P2's filter (which P1 moves to ignore)
local wp_excluded = { [0] = {}, [1] = {} }

pcall(function()
    local data = json.load_file(WP_CONFIG_FILE)
    if data then
        if data["0"] then wp_excluded[0] = data["0"] end
        if data["1"] then wp_excluded[1] = data["1"] end
    end
end)

local function save_wp_filter()
    json.dump_file(WP_CONFIG_FILE, { ["0"] = wp_excluded[0], ["1"] = wp_excluded[1] })
end

local function has_any_exclusion(player)
    for _, _ in pairs(wp_excluded[player]) do return true end
    return false
end

local function is_move_excluded(player, input_notation)
    return wp_excluded[player][input_notation] == true
end

-- =========================================================
-- INPUT NOTATION HELPERS (for identifying opponent's move)
-- =========================================================
local function get_numpad_notation(dir_val)
    if not dir_val then return "5" end
    local u, d, l, r = (dir_val & 1) ~= 0, (dir_val & 2) ~= 0, (dir_val & 4) ~= 0, (dir_val & 8) ~= 0
    if u and l then return "7" elseif u and r then return "9" elseif d and l then return "1" elseif d and r then return "3"
    elseif u then return "8" elseif d then return "2" elseif l then return "4" elseif r then return "6" end
    return "5"
end

local function get_btn_text(val)
    if not val or val == 0 then return "" end
    local btns = {}
    if (val & 16) ~= 0  then table.insert(btns, "LP") end
    if (val & 32) ~= 0  then table.insert(btns, "MP") end
    if (val & 64) ~= 0  then table.insert(btns, "HP") end
    if (val & 128) ~= 0 then table.insert(btns, "LK") end
    if (val & 256) ~= 0 then table.insert(btns, "MK") end
    if (val & 512) ~= 0 then table.insert(btns, "HK") end
    if #btns == 0 then return "" end
    return table.concat(btns, "")
end

local function read_opp_full_input(opp_index)
    local ok, result = pcall(function()
        local gBattle = sdk.find_type_definition("gBattle")
        if not gBattle then return nil end
        local pmgr = gBattle:get_field("Player"):get_data(nil)
        if not pmgr then return nil end
        local p = pmgr:call("getPlayer", opp_index)
        if not p then return nil end
        local td = p:get_type_definition()
        local f_in = td:get_field("pl_input_new")
        local f_sw = td:get_field("pl_sw_new")
        local dv = (f_in and f_in:get_data(p)) or 0
        local bv = (f_sw and f_sw:get_data(p)) or 0
        local btn = get_btn_text(bv)
        if btn == "" then return nil end
        return get_numpad_notation(dv) .. btn
    end)
    return ok and result or nil
end

-- WP filter submenu: independent open state per player
local wp_submenu_open = { [0] = false, [1] = false }
local wp_submenu_rects = { [0] = nil, [1] = nil } -- saved rects for overlap detection
-- Screen position for ">" buttons per player (set by D2D, read by imgui)
local wp_btn_screen = {
    [0] = { x = 0, y = 0, w = 0, h = 0, panel_x = 0, panel_w = 0 },
    [1] = { x = 0, y = 0, w = 0, h = 0, panel_x = 0, panel_w = 0 },
}
local rst_btn_screen = {
    [0] = { x = 0, y = 0, w = 0, h = 0 },
    [1] = { x = 0, y = 0, w = 0, h = 0 },
}
local rst_flash = { [0] = 0, [1] = 0 -- countdown frames for red flash
}

-- Hook character detection
pcall(function()
    local t_med = sdk.find_type_definition("app.FBattleMediator")
    if not t_med then return end
    local method = t_med:get_method("UpdateGameInfo")
    if not method then return end
    sdk.hook(method, function(args)
        local managed_obj = sdk.to_managed_object(args[2])
        if managed_obj then
            local f_pt = t_med:get_field("PlayerType")
            if f_pt then
                local array = f_pt:get_data(managed_obj)
                if array and array:call("get_Length") >= 2 then
                    for i = 0, 1 do
                        local obj = array:call("GetValue", i)
                        if obj then
                            local pid = obj:get_type_definition():get_field("value__"):get_data(obj)
                            local esf = string.format("ESF_%03d", pid)
                            wp_char_names[i] = esf_names_map[esf] or esf
                        end
                    end
                end
            end
        end
    end, function(r) return r end)
end)

local stance_variants = {
    ["Chun-Li"] = "ChunLi_Serenity",
    ["Alex"] = "Alex_Prowler",
}

local function get_low_ar_from(source, name)
    local d = source[name]
    if d and d.low and d.low.ar then return d.low.ar end
    return 0
end

local function get_red_ar(char_name, player_idx)
    -- Nom dynamique (stance-aware) depuis le Distance Viewer
    local dynamic_name = char_name
    if _G.DV_PlayerAdvName and _G.DV_PlayerAdvName[player_idx] then
        dynamic_name = _G.DV_PlayerAdvName[player_idx]
    end

    -- Source de vérité unique : Viewer prefs pour CE joueur
    local vp = get_viewer_prefs()
    if vp[player_idx] then
        local v = get_low_ar_from(vp[player_idx], dynamic_name)
        if v > 0 then return v end
    end

    return 0
end

-- Get closest distance from opponent's HURTBOX edges to player's position
local function get_hurtbox_dist(player_obj, ref_x)
    local min_dist = 999999.0
    if not player_obj or not player_obj.mpActParam or not player_obj.mpActParam.Collision then return min_dist end
    local col = player_obj.mpActParam.Collision
    if col.Infos and col.Infos._items then
        for _, r in pairs(col.Infos._items) do
            -- HitNo = hurtbox, Type 0 = normal (not invuln)
            if r and r:get_field("HitNo") ~= nil and (r.Type == 0 or r.Type == nil) then
                local box_x = (r.OffsetX and r.OffsetX.v) and (r.OffsetX.v / 6553600.0) or 0.0
                local size_x = (r.SizeX and r.SizeX.v) and (r.SizeX.v / 6553600.0) or 0.0
                local d_left = math.abs(ref_x - (box_x - size_x))
                local d_right = math.abs(ref_x - (box_x + size_x))
                if d_left < min_dist then min_dist = d_left end
                if d_right < min_dist then min_dist = d_right end
            end
        end
    end
    return min_dist
end

-- Returns true if opponent is within player P's red zone
local function is_opp_in_red_zone(p)
    local ok, result = pcall(function()
        local gBattle = sdk.find_type_definition("gBattle")
        if not gBattle then return false end
        local pmgr = gBattle:get_field("Player"):get_data(nil)
        if not pmgr then return false end
        local cP = pmgr.mcPlayer
        if not cP or not cP[0] or not cP[1] then return false end
        local opp = 1 - p
        local opp_obj = cP[opp]
        local my_x = cP[p].pos.x.v / 6553600.0
        local dist = get_hurtbox_dist(opp_obj, my_x)
        local my_ar = get_red_ar(wp_char_names[p], p)
        return dist <= (my_ar / 100.0) + 0.001
    end)
    return ok and result
end

-- =========================================================
-- STATE
-- =========================================================
local STATS = { "pp", "wp", "hc", "aa" }
local LABELS = { pp = "PP", wp = "WP", hc = "HC", aa = "AA" }
local STAT_COLORS = { pp = COL.pp, wp = COL.wp, hc = COL.hc, aa = COL.aa }
local FULL_LABELS = { pp = "PERFECT PARRY", wp = "WHIFF PUNISH", hc = "HIT CONFIRM", aa = "ANTI AIR" }

local counters = {
    [0] = { pp = 0, wp = 0, wp_ok = 0, wp_opp = 0, hc = 0, hc_ok = 0, hc_opp = 0, aa = 0, aa_ok = 0, aa_opp = 0 },
    [1] = { pp = 0, wp = 0, wp_ok = 0, wp_opp = 0, hc = 0, hc_ok = 0, hc_opp = 0, aa = 0, aa_ok = 0, aa_opp = 0 },
}

-- Per-player tracking
local track = {
    [0] = { act_st = 0, prev_act_st = 0, pose_st = 0, frame_st = 0, prev_frame_st = 0, was_airborne = false },
    [1] = { act_st = 0, prev_act_st = 0, pose_st = 0, frame_st = 0, prev_frame_st = 0, was_airborne = false },
}

-- Frame state from hooks
local p1_max_frame = 0
local p2_max_frame = 0

-- Fonts
local _font = nil
local _font_small = nil
local _last_fh = 0
local _last_fhs = 0

-- =========================================================
-- GAME STATE READING
-- =========================================================
local function get_player(index)
    local gBattle = sdk.find_type_definition("gBattle")
    if not gBattle then return nil end
    local player_mgr = gBattle:get_field("Player"):get_data(nil)
    if not player_mgr then return nil end
    return player_mgr:call("getPlayer", index)
end

local function get_act_st(player_index)
    local player = get_player(player_index)
    if not player then return 0 end
    local t = player:get_type_definition()
    if not t then return 0 end
    local field = t:get_field("act_st")
    if not field then return 0 end
    local val = field:get_data(player)
    return tonumber(tostring(val)) or 0
end

local function get_pose_st(player_index)
    local player = get_player(player_index)
    if not player then return 0 end
    local pose = player:get_field("pose_st")
    if pose then return tonumber(tostring(pose)) or 0 end
    return 0
end

-- =========================================================
-- FRAME DATA READING (same approach as HitConfirm matrix)
-- =========================================================
local matrix = {
    p1_list = nil, p2_list = nil,  -- persistent references
    p1_ft = 0, p1_gau = 0, prev_p1_ft = 0, prev_p1_gau = 0,
    p2_ft = 0, p2_gau = 0, prev_p2_ft = 0, prev_p2_gau = 0,
    last_head = -1,
    is_new = false,
    debug_status = "not initialized"
}

local function read_frame_data()
    -- Read player data EVERY frame (combo, dmg, hs, trade_dm)
    -- Same as HitConfirm which reads these at the top of update_detection()
    matrix.prev_p1_combo = matrix.p1_combo or 0
    matrix.prev_p2_combo = matrix.p2_combo or 0
    matrix.p1_dmg = 0; matrix.p1_hs = 0; matrix.p1_combo = 0
    matrix.p2_dmg = 0; matrix.p2_hs = 0; matrix.p2_combo = 0
    matrix.p1_trade_dm = false; matrix.p2_trade_dm = false
    matrix.p1_pose_st = 0; matrix.p2_pose_st = 0
    matrix.p1_suki = false; matrix.p2_suki = false
    matrix.p1_parry_combo = 0; matrix.p2_parry_combo = 0
    pcall(function()
        local gBattle = sdk.find_type_definition("gBattle")
        if not gBattle then return end
        local pmgr = gBattle:get_field("Player"):get_data(nil)
        if not pmgr then return end
        local p1_obj = pmgr:call("getPlayer", 0)
        local p2_obj = pmgr:call("getPlayer", 1)
        if p1_obj then
            local dt = p1_obj:get_field("damage_type"); if dt then matrix.p1_dmg = tonumber(tostring(dt)) or 0 end
            local hs = p1_obj:get_field("hit_stop"); if hs then matrix.p1_hs = tonumber(tostring(hs)) or 0 end
            local cc = p1_obj:get_field("combo_cnt"); if cc then matrix.p1_combo = tonumber(tostring(cc)) or 0 end
            local td = p1_obj:get_field("trade_dm_flag"); if td then matrix.p1_trade_dm = (tostring(td) == "true") end
            local ps = p1_obj:get_field("pose_st"); if ps then matrix.p1_pose_st = tonumber(tostring(ps)) or 0 end
            local sk = p1_obj:get_field("land_suki_flag"); if sk then matrix.p1_suki = (tostring(sk) == "true") end
            local pc = p1_obj:get_field("parry_combo_cnt"); if pc then matrix.p1_parry_combo = tonumber(tostring(pc)) or 0 end
        end
        if p2_obj then
            local dt = p2_obj:get_field("damage_type"); if dt then matrix.p2_dmg = tonumber(tostring(dt)) or 0 end
            local hs = p2_obj:get_field("hit_stop"); if hs then matrix.p2_hs = tonumber(tostring(hs)) or 0 end
            local cc = p2_obj:get_field("combo_cnt"); if cc then matrix.p2_combo = tonumber(tostring(cc)) or 0 end
            local td = p2_obj:get_field("trade_dm_flag"); if td then matrix.p2_trade_dm = (tostring(td) == "true") end
            local ps = p2_obj:get_field("pose_st"); if ps then matrix.p2_pose_st = tonumber(tostring(ps)) or 0 end
            local sk = p2_obj:get_field("land_suki_flag"); if sk then matrix.p2_suki = (tostring(sk) == "true") end
            local pc = p2_obj:get_field("parry_combo_cnt"); if pc then matrix.p2_parry_combo = tonumber(tostring(pc)) or 0 end
        end
    end)

    -- Acquire matrix lists (re-acquire if stale)
    local lists_ok = false
    if matrix.p1_list and matrix.p2_list then
        local ok = pcall(function()
            local c = matrix.p1_list:call("get_Count")
            if not c or c <= 0 then error("stale") end
        end)
        if ok then lists_ok = true else matrix.p1_list = nil; matrix.p2_list = nil; matrix.last_head = -1 end
    end
    if not lists_ok then
        local mgr = sdk.get_managed_singleton("app.training.TrainingManager")
        if not mgr then matrix.debug_status = "no TrainingManager"; return false end
        local dict = mgr:get_field("_ViewUIWigetDict")
        local entries = dict and dict:get_field("_entries")
        if not entries then matrix.debug_status = "no entries"; return false end

        local count = entries:call("get_Count")
        for i = 0, count - 1 do
            local entry = entries:call("get_Item", i)
            if entry:get_field("key") == 5 then
                local widget = entry:get_field("value"):call("get_Item", 0)
                local ss = widget:call("get_SSData")
                local m_datas = ss:get_field("MeterDatas")
                if m_datas and m_datas:call("get_Count") >= 2 then
                    local item_p1 = m_datas:call("get_Item", 0)
                    local item_p2 = m_datas:call("get_Item", 1)
                    if item_p1 then matrix.p1_list = item_p1:get_field("FrameNumDatas") end
                    if item_p2 then matrix.p2_list = item_p2:get_field("FrameNumDatas") end
                end
                break
            end
        end
        if not matrix.p1_list or not matrix.p2_list then
            matrix.debug_status = "no FrameNumDatas"
            return false
        end
        matrix.debug_status = "lists acquired"
    end

    -- Read from persistent lists (exact same logic as HitConfirm)
    local buffer_count = matrix.p1_list:call("get_Count")
    if buffer_count <= 0 then matrix.debug_status = "buffer empty"; return false end

    local function check_active(idx)
        if idx < 0 or idx >= buffer_count then return false end
        local item1 = matrix.p1_list:call("get_Item", idx)
        local item2 = matrix.p2_list:call("get_Item", idx)
        if not item1 or not item2 then return false end
        local ft1 = tonumber(tostring(item1:get_field("FrameType"))) or 0
        local ft2 = tonumber(tostring(item2:get_field("FrameType"))) or 0
        return (ft1 ~= 0 or ft2 ~= 0)
    end

    local active_head = -1
    local next_idx = (matrix.last_head + 1) % buffer_count
    matrix.is_new = false

    if check_active(next_idx) then
        active_head = next_idx
        matrix.is_new = true
    elseif check_active(matrix.last_head) then
        active_head = matrix.last_head
    else
        -- Fallback: scan backwards for last active slot
        for i = buffer_count - 1, 0, -1 do
            if check_active(i) then active_head = i; break end
        end
    end

    if active_head == -1 then matrix.debug_status = "no active head"; return false end
    matrix.last_head = active_head

    if not matrix.is_new then return false end -- no new frame data

    local it1 = matrix.p1_list:call("get_Item", active_head)
    local it2 = matrix.p2_list:call("get_Item", active_head)
    if not it1 or not it2 then return false end

    -- Save previous
    matrix.prev_p1_ft  = matrix.p1_ft
    matrix.prev_p1_gau = matrix.p1_gau
    matrix.prev_p1_dmg = matrix.p1_dmg
    matrix.prev_p1_hs  = matrix.p1_hs
    matrix.prev_p2_ft  = matrix.p2_ft
    matrix.prev_p2_gau = matrix.p2_gau
    matrix.prev_p2_dmg = matrix.p2_dmg
    matrix.prev_p2_hs  = matrix.p2_hs

    -- Read ALL fields from both items for debug mapping
    matrix.p1_ft  = tonumber(tostring(it1:get_field("FrameType")))  or 0
    matrix.p1_type = tonumber(tostring(it1:get_field("Type")))  or 0
    matrix.p1_frame = tonumber(tostring(it1:get_field("Frame")))  or 0
    matrix.p1_sf  = tonumber(tostring(it1:get_field("StartFrame")))  or 0
    matrix.p1_ef  = tonumber(tostring(it1:get_field("EndFrame")))  or 0
    matrix.p1_gau = tonumber(tostring(it1:get_field("MainGauge"))) or 0

    matrix.p2_ft  = tonumber(tostring(it2:get_field("FrameType")))  or 0
    matrix.p2_type = tonumber(tostring(it2:get_field("Type")))  or 0
    matrix.p2_frame = tonumber(tostring(it2:get_field("Frame")))  or 0
    matrix.p2_sf  = tonumber(tostring(it2:get_field("StartFrame")))  or 0
    matrix.p2_ef  = tonumber(tostring(it2:get_field("EndFrame")))  or 0
    matrix.p2_gau = tonumber(tostring(it2:get_field("MainGauge"))) or 0

    matrix.debug_status = string.format("OK head=%d", active_head)
    return true
end

-- =========================================================
-- FRAME METER HOOKS (for WP, HC, AA detection)
-- =========================================================
local function setup_hooks()
    local t_fm = sdk.find_type_definition("app.training.UIWidget_TMFrameMeter")
    if not t_fm then return end

    local m_up = t_fm:get_method("SetUpFrame")
    if m_up then
        sdk.hook(m_up, function(args)
            local s = tonumber(tostring(sdk.to_int64(args[4])))
            if s and s > p1_max_frame then p1_max_frame = s end
        end, function(r) return r end)
    end

    local m_down = t_fm:get_method("SetDownFrame")
    if m_down then
        sdk.hook(m_down, function(args)
            local s = tonumber(tostring(sdk.to_int64(args[4])))
            if s and s > p2_max_frame then p2_max_frame = s end
        end, function(r) return r end)
    end
end

pcall(setup_hooks)

-- =========================================================
-- INPUT READING (for button detection)
-- =========================================================
local function read_game_input(player_index)
    local gBattle = sdk.find_type_definition("gBattle")
    if not gBattle then return 0 end
    local pmgr = gBattle:get_field("Player"):get_data(nil)
    if not pmgr then return 0 end
    local p = pmgr:call("getPlayer", player_index)
    if not p then return 0 end
    local f_sw = p:get_type_definition():get_field("pl_sw_new")
    if not f_sw then return 0 end
    return f_sw:get_data(p) or 0
end

-- =========================================================
-- DETECTION LOGIC
-- =========================================================
-- Matrix FT values: 7=startup, 8=recovery, 9=hurt/block, 13/14=active
-- Matrix GAU values: 34=perfect parry
local STATE_NEUTRAL  = 0
local STATE_RECOVER  = 8
local STATE_HURT     = 9
local FT_ACTIVE_1    = 13
local FT_ACTIVE_2    = 14
local GAU_PARRY      = 34

local function is_active(ft)
    return ft == FT_ACTIVE_1 or ft == FT_ACTIVE_2
end

local function detect_events()
    -- Read hook-based states (for WP, HC, AA)
    for p = 0, 1 do
        track[p].prev_act_st = track[p].act_st
        track[p].prev_frame_st = track[p].frame_st
        track[p].act_st = get_act_st(p)
        track[p].pose_st = get_pose_st(p)
    end
    track[0].frame_st = p1_max_frame
    track[1].frame_st = p2_max_frame
    p1_max_frame = 0
    p2_max_frame = 0

    -- Read matrix data (for PP detection)
    local has_matrix = pcall(read_frame_data)

    -- =====================
    -- PERFECT PARRY
    -- PostGuard mode: trade_dm_flag only (unlock when trade_dm goes false)
    -- Custom mode: trade_dm + dmg=34 + hs!=0 (unlock when hs returns to 0)
    -- =====================
    if has_matrix then
        for pp_p = 0, 1 do
            local dm  = (pp_p == 0) and matrix.p1_trade_dm or matrix.p2_trade_dm
            local dmg = (pp_p == 0) and (matrix.p1_dmg or 0) or (matrix.p2_dmg or 0)
            local hs  = (pp_p == 0) and (matrix.p1_hs or 0) or (matrix.p2_hs or 0)
            local pcc = (pp_p == 0) and (matrix.p1_parry_combo or 0) or (matrix.p2_parry_combo or 0)
            -- parry_combo_cnt > 0 = normal parry (held parry), must be 0 for perfect parry
            local not_normal_parry = (pcc == 0)

            if cfg.pp_postguard_mode then
                -- PostGuard: trade_dm_flag + not normal parry, unlock when dm goes false
                if not dm then track[pp_p]._pp_locked = false end
                if not track[pp_p]._pp_locked and dm and not_normal_parry then
                    counters[pp_p].pp = counters[pp_p].pp + 1
                    track[pp_p]._pp_locked = true
                end
            else
                -- Custom: trade_dm + dmg=34 + hs!=0 + not normal parry, unlock when hs=0
                if hs == 0 then track[pp_p]._pp_locked = false end
                if not track[pp_p]._pp_locked and dm and not_normal_parry and dmg == 34 and hs ~= 0 then
                    counters[pp_p].pp = counters[pp_p].pp + 1
                    track[pp_p]._pp_locked = true
                end
            end
        end
    end

    for p = 0, 1 do
        local opp = 1 - p
        local t_p = track[p]
        local t_o = track[opp]

        -- =====================
        -- WHIFF PUNISH (only tracks opponent moves that WHIFF, not moves that connect)
        -- Score: +1 if P punishes whiffed move, -1 if missed opportunity
        -- Cancel tracking if opponent's attack actually hits player (not a whiff)
        -- =====================
        local opp_state = (opp == 0) and track[0].frame_st or track[1].frame_st
        local opp_pose  = (opp == 0) and (matrix.p1_pose_st or 0) or (matrix.p2_pose_st or 0)
        local my_state  = (p == 0) and track[0].frame_st or track[1].frame_st

        -- Opponent is grounded and attacking — start tracking always, zone checked during
        if opp_pose < 2 and not t_p._wp_tracking and not t_p._wp_cooldown then
            if opp_state == 7 or opp_state == 13 or opp_state == 14 or opp_state == STATE_RECOVER then
                t_p._wp_tracking = true
                t_p._wp_counted = false
                t_p._wp_entered_zone = false
                t_p._wp_is_light = false
                t_p._wp_move_input = nil
                t_p._wp_filtered_out = false
                pcall(function()
                    local opp_input = read_game_input(opp)
                    if (opp_input & MASK_LIGHT) ~= 0 then t_p._wp_is_light = true end
                    t_p._wp_move_input = read_opp_full_input(opp)
                end)
                -- Immediate filter if we got the input
                if t_p._wp_move_input and is_move_excluded(p, t_p._wp_move_input) then
                    t_p._wp_tracking = false
                    t_p._wp_filtered_out = true
                end
            end
        end

        -- Keep trying to identify the move while tracking (button may have been released on first frame)
        if t_p._wp_tracking and not t_p._wp_move_input then
            pcall(function()
                local input = read_opp_full_input(opp)
                if input then
                    t_p._wp_move_input = input
                    if is_move_excluded(p, input) then
                        t_p._wp_tracking = false
                        t_p._wp_filtered_out = true
                    end
                end
            end)
        end

        -- Cooldown resets when opponent returns to neutral
        if t_p._wp_cooldown and (opp_state == STATE_NEUTRAL or opp_state == 0) then
            t_p._wp_cooldown = false
        end

        if t_p._wp_tracking then
            -- If move still unidentified and we have exclusions, skip entirely
            local wp_skip = (not t_p._wp_move_input and has_any_exclusion(p))

            -- Check if opponent enters red zone only during recovery (FrameType 8)
            local opp_ft = (opp == 0) and matrix.p1_ft or matrix.p2_ft
            if not wp_skip and not t_p._wp_entered_zone and opp_ft == 8 and is_opp_in_red_zone(p) then
                t_p._wp_entered_zone = true
            end

            -- If PLAYER got hit or blocked, opponent's move connected = NOT a whiff, cancel
            if my_state == STATE_HURT or my_state == 10 then
                t_p._wp_tracking = false
                t_p._wp_counted = false
                t_p._wp_cooldown = true
            elseif opp_state == STATE_HURT then
                -- Player punished the opponent = SUCCESS (only if was in zone and not filtered)
                if not wp_skip and not t_p._wp_counted and t_p._wp_entered_zone then
                    counters[p].wp = counters[p].wp + 1
                    counters[p].wp_ok = counters[p].wp_ok + 1
                    counters[p].wp_opp = counters[p].wp_opp + 1
                    t_p._wp_counted = true
                end
                t_p._wp_tracking = false
                t_p._wp_cooldown = true
            elseif opp_state == STATE_NEUTRAL or opp_state == 0 then
                -- Opponent returned to neutral unpunished
                if not wp_skip and not t_p._wp_counted and t_p._wp_entered_zone then
                    if t_p._wp_is_light then
                        counters[p].wp_opp = counters[p].wp_opp + 1
                    else
                        counters[p].wp = counters[p].wp - 1
                        counters[p].wp_opp = counters[p].wp_opp + 1
                    end
                end
                -- Never entered zone = ignore completely
                t_p._wp_tracking = false
                t_p._wp_counted = false
            end
        end

        -- =====================
        -- ANTI AIR (PostGuard logic)
        -- Only tracks when OPPONENT is airborne AND attacking (suki_flag)
        -- +1 if opponent hit while airborne attacking, -1 if lands safely
        -- =====================
        local opp_suki = (opp == 0) and matrix.p1_suki or matrix.p2_suki
        local my_pose = (p == 0) and (matrix.p1_pose_st or 0) or (matrix.p2_pose_st or 0)

        -- Skip AA tracking entirely if player P is being comboed (hurt/airborne)
        local my_state_raw = (p == 0) and track[0].frame_st or track[1].frame_st
        local p_is_hurt = (my_state_raw == STATE_HURT)

        -- Special case: Alex Prowler MK (action 980) — looks grounded but is airborne
        local opp_airborne_override = false
        local p_is_doing_980 = false
        pcall(function()
            local gBattle = sdk.find_type_definition("gBattle")
            if not gBattle then return end
            local pmgr = gBattle:get_field("Player"):get_data(nil)
            if not pmgr then return end
            -- Check opponent for airborne override
            local opp_obj = pmgr:call("getPlayer", opp)
            if opp_obj then
                local eng = opp_obj.mpActParam and opp_obj.mpActParam.ActionPart and opp_obj.mpActParam.ActionPart._Engine
                if eng then
                    local act_id = eng:get_ActionID()
                    if act_id == 980 then
                        local y_val = opp_obj.pos and opp_obj.pos.y and opp_obj.pos.y.v or 0
                        if y_val > 100000 then
                            opp_airborne_override = true
                        end
                    end
                end
            end
            -- Check if player P is doing action 980 (skip AA tracking for this player)
            local p_obj = pmgr:call("getPlayer", p)
            if p_obj then
                local eng = p_obj.mpActParam and p_obj.mpActParam.ActionPart and p_obj.mpActParam.ActionPart._Engine
                if eng and eng:get_ActionID() == 980 then
                    p_is_doing_980 = true
                end
            end
        end)

        local opp_is_airborne = (opp_pose >= 2) or opp_airborne_override

        -- Check if opponent is being comboed (hurt while airborne = launched, not jumping)
        local opp_is_launched = (opp_is_airborne and opp_state == STATE_HURT)

        -- If player P is doing prowler MK, mark to skip AA for this whole sequence
        if p_is_doing_980 then
            t_p._aa_skip_980 = true
        end
        -- Reset the skip flag when back on ground and neutral
        if not p_is_doing_980 and opp_pose < 2 and (my_state_raw == STATE_NEUTRAL or my_state_raw == 0) then
            t_p._aa_skip_980 = false
        end

        if t_p._aa_skip_980 and t_p._aa_opp_in_air then
            t_p._aa_opp_in_air = false
            t_p._aa_opp_attacking = false
            t_p._aa_counted = false
            t_p._aa_launched = false
        end

        if not p_is_hurt and not t_p._aa_skip_980 and opp_is_airborne and not opp_is_launched then
            if not t_p._aa_opp_in_air then
                t_p._aa_opp_in_air = true
                t_p._aa_launched = false
            end
            if opp_suki or opp_airborne_override then t_p._aa_opp_attacking = true end
        elseif opp_is_launched and not t_p._aa_opp_in_air then
            t_p._aa_launched = true
        end

        -- Cancel AA tracking if player gets hurt BUT only if opponent wasn't attacking from air
        -- (if opponent was jump-attacking and hits you, that's a failed AA = -1)
        if p_is_hurt and t_p._aa_opp_in_air and not t_p._aa_opp_attacking then
            t_p._aa_opp_in_air = false
            t_p._aa_opp_attacking = false
            t_p._aa_counted = false
            t_p._aa_launched = false
        end

        if t_p._aa_opp_in_air and not t_p._aa_launched then
            -- SUCCESS: opponent was attacking from air and got hit (AA'd)
            if t_p._aa_opp_attacking and opp_state == STATE_HURT and my_pose < 2 then
                if not t_p._aa_counted then
                    counters[p].aa = counters[p].aa + 1
                    counters[p].aa_ok = counters[p].aa_ok + 1
                    counters[p].aa_opp = counters[p].aa_opp + 1
                    t_p._aa_counted = true
                end
            end
            -- FAIL: opponent jump-attacked and HIT YOU (you got hurt by the jump-in)
            if t_p._aa_opp_attacking and p_is_hurt and not t_p._aa_counted then
                counters[p].aa = counters[p].aa - 1
                counters[p].aa_opp = counters[p].aa_opp + 1
                t_p._aa_counted = true
            end
            -- Opponent landed (back on ground + neutral)
            if not opp_is_airborne and (opp_state == STATE_NEUTRAL or opp_state == 0) then
                -- Landed safely without being AA'd and without hitting you = also a fail
                if t_p._aa_opp_attacking and not t_p._aa_counted then
                    counters[p].aa = counters[p].aa - 1
                    counters[p].aa_opp = counters[p].aa_opp + 1
                end
                t_p._aa_opp_in_air = false
                t_p._aa_opp_attacking = false
                t_p._aa_counted = false
                t_p._aa_launched = false
            end
        elseif not opp_is_airborne then
            -- Reset all AA state when opponent is back on ground
            t_p._aa_opp_in_air = false
            t_p._aa_opp_attacking = false
            t_p._aa_counted = false
            t_p._aa_launched = false
        end

        -- =====================
        -- HIT CONFIRM (full HitConfirm engine logic)
        -- =====================
        local hs = hc_state[p]
        local mon = hs.monitor

        -- Get matrix data for attacker (p) and opponent (opp)
        local p_ft  = (p == 0) and matrix.p1_ft  or matrix.p2_ft
        local p_gau = (p == 0) and matrix.p1_gau or matrix.p2_gau
        local opp_ft  = (p == 0) and matrix.p2_ft  or matrix.p1_ft
        local opp_gau = (p == 0) and matrix.p2_gau or matrix.p1_gau
        local live_dmg   = (opp == 0) and matrix.p1_dmg   or matrix.p2_dmg
        local live_hs    = (opp == 0) and matrix.p1_hs    or matrix.p2_hs
        local live_combo = (p == 0)   and matrix.p1_combo or matrix.p2_combo

        -- Track button presses for this player
        pcall(function()
            local input = read_game_input(p)
            if (input & MASK_LIGHT) ~= 0 then hs.last_light_time = os.clock() end
            if (input & MASK_MEDIUM) ~= 0 then hs.last_medium_time = os.clock() end
            if (input & MASK_HEAVY) ~= 0 then hs.last_heavy_time = os.clock() end
        end)

        local is_light_buffered  = (os.clock() - hs.last_light_time) < 0.25
        local is_medium_buffered = (os.clock() - hs.last_medium_time) < 0.5
        local required_combo_start = is_light_buffered and 2 or 1

        -- 1) LOCKOUT RESET
        if hs.lockout then
            if not is_in(hc_work.trigger, p_ft) and not is_in(hc_work.break_list, p_ft) then
                hs.lockout = false
            end
        end

        -- 2) TRIGGER CONDITIONS
        local is_ft_trig   = is_in(hc_work.trigger, p_ft)
        local is_dmg_hit   = is_in(hc_work.dmg_hit, live_dmg)
        local is_dmg_blk   = is_in(hc_work.dmg_block, live_dmg)
        local trig_hit = (is_ft_trig and live_combo == required_combo_start and is_dmg_hit)
        local trig_blk = (is_ft_trig and opp_gau > 0 and is_dmg_blk)

        -- 3) HIT TRIGGER
        if trig_hit and not hs.lockout then
            if not mon.active or mon.type ~= "HIT" then
                mon.active = true; mon.type = "HIT"; mon.has_reset_hs = false
                mon.target_combo = required_combo_start + 1
            end
        -- 4) BLOCK TRIGGER
        elseif trig_blk and not hs.lockout then
            if not mon.active or mon.type ~= "BLOCK" then
                mon.active = true; mon.type = "BLOCK"; mon.has_reset_hs = false
                mon.is_medium = is_medium_buffered
            end
        end

        -- 5) STANDARD MONITOR (exact same logic as HitConfirm)
        if mon.active and not hs.lockout then
            if live_hs == 0 then mon.has_reset_hs = true end
            if mon.has_reset_hs then
                if mon.type == "HIT" then
                    if live_combo >= mon.target_combo then
                        -- SUCCESS: confirmed hit into combo
                        counters[p].hc = counters[p].hc + 1
                        counters[p].hc_ok = counters[p].hc_ok + 1
                        counters[p].hc_opp = counters[p].hc_opp + 1
                        mon.active = false; hs.lockout = true
                    elseif live_combo == 0 then
                        -- FAIL: dropped combo
                        counters[p].hc = counters[p].hc - 1
                        counters[p].hc_opp = counters[p].hc_opp + 1
                        mon.active = false; hs.lockout = true
                    end
                elseif mon.type == "BLOCK" then
                    if is_in(hc_work.break_list, p_ft) then
                        -- FAIL: unsafe on block
                        counters[p].hc = counters[p].hc - 1
                        counters[p].hc_opp = counters[p].hc_opp + 1
                        mon.active = false; hs.lockout = true
                    elseif is_in(hc_work.success, p_ft) and not is_in(hc_work.trigger, p_ft) and live_hs > 0 then
                        -- FAIL: autopilot (kept pressing buttons)
                        counters[p].hc = counters[p].hc - 1
                        counters[p].hc_opp = counters[p].hc_opp + 1
                        mon.active = false; hs.lockout = true
                    elseif not is_in(hc_work.dmg_block, live_dmg) then
                        -- Block resolved: stopped pressing
                        counters[p].hc_opp = counters[p].hc_opp + 1
                        if not hc_cfg.dont_count_blocked then
                            counters[p].hc = counters[p].hc + 1
                            counters[p].hc_ok = counters[p].hc_ok + 1
                        end
                        mon.active = false; hs.lockout = true
                    end
                end
            end
        end
    end
end

-- =========================================================
-- ROUND RESET (Battle Hub) : reset stats quand le timer repart
-- =========================================================
local _match_stats_reset = false

local function reset_all_stats()
    for p = 0, 1 do
        for _, k in ipairs(STATS) do counters[p][k] = 0 end
        counters[p].wp_ok = 0; counters[p].wp_opp = 0
        counters[p].hc_ok = 0; counters[p].hc_opp = 0
        counters[p].aa_ok = 0; counters[p].aa_opp = 0
        hc_state[p].monitor.active = false; hc_state[p].monitor.type = nil
        hc_state[p].monitor.has_reset_hs = false; hc_state[p].monitor.target_combo = 0
        hc_state[p].lockout = false
        track[p]._wp_tracking = false; track[p]._aa_opp_in_air = false
        track[p]._aa_opp_attacking = false; track[p]._aa_counted = false
    end
end

-- =========================================================
-- GAME LOOP
-- =========================================================
re.on_frame(function()
    if not should_show() then
        wp_submenu_open[0] = false
        wp_submenu_open[1] = false
        return
    end

    -- Reset stats au début d'un nouveau match (fight_st == STAGE_INIT)
    pcall(function()
        local gB = sdk.find_type_definition("gBattle")
        if not gB then return end
        local sGame = gB:get_field("Game"):get_data(nil)
        if not sGame then return end
        local fs = sGame.fight_st
        if fs == 0 and not _match_stats_reset then
            reset_all_stats()
            _match_stats_reset = true
        elseif fs ~= 0 then
            _match_stats_reset = false
        end
    end)

    pcall(detect_events)

    -- Click detection on WP ">"/"<" buttons
    pcall(function()
        if imgui.is_mouse_clicked(0) then
            local m = imgui.get_mouse()
            if m then
                for p = 0, 1 do
                    local b = wp_btn_screen[p]
                    if b.w > 0 and m.x >= b.x and m.x <= b.x + b.w and m.y >= b.y and m.y <= b.y + b.h then
                        wp_submenu_open[p] = not wp_submenu_open[p]
                        break
                    end
                end
            end
        end
    end)

    -- Click detection on RST buttons
    pcall(function()
        if imgui.is_mouse_clicked(0) then
            local m = imgui.get_mouse()
            if m then
                for p = 0, 1 do
                    local b = rst_btn_screen[p]
                    if b.w > 0 and m.x >= b.x and m.x <= b.x + b.w and m.y >= b.y and m.y <= b.y + b.h then
                        for _, k in ipairs(STATS) do counters[p][k] = 0 end
                        counters[p].wp_ok = 0; counters[p].wp_opp = 0
                        counters[p].hc_ok = 0; counters[p].hc_opp = 0
                        counters[p].aa_ok = 0; counters[p].aa_opp = 0
                        hc_state[p].monitor.active = false; hc_state[p].monitor.type = nil
                        hc_state[p].monitor.has_reset_hs = false; hc_state[p].monitor.target_combo = 0
                        hc_state[p].lockout = false
                        track[p]._wp_tracking = false; track[p]._aa_opp_in_air = false
                        track[p]._aa_opp_attacking = false; track[p]._aa_counted = false
                        rst_flash[p] = 20
                        break
                    end
                end
            end
        end
    end)

    -- Draw WP filter submenus (one per player, independent)
    for p = 0, 1 do
        if not wp_submenu_open[p] then
            wp_submenu_rects[p] = nil
        end
        if wp_submenu_open[p] then
            local opp = 1 - p
            local char_name = wp_char_names[opp]
            local b = wp_btn_screen[p]
            local excl = wp_excluded[p]

            local sub_x, sub_y
            if p == 0 then
                sub_x = b.panel_x + b.panel_w + 4
            else
                sub_x = b.panel_x - 204
            end
            sub_y = b.y

            imgui.push_style_color(2, COL.bg)
            imgui.push_style_color(5, COL.border)
            imgui.push_style_color(0, COL.text)
            imgui.push_style_color(7, 0x44FFFFFF)
            imgui.push_style_color(18, COL.wp)
            imgui.push_style_color(21, 0x44FFFFFF)
            imgui.push_style_color(22, 0x66FFFFFF)
            imgui.push_style_color(23, 0x88FFFFFF)

            imgui.set_next_window_pos(Vector2f.new(sub_x, sub_y), 1 << 2)
            imgui.set_next_window_size(Vector2f.new(200, 400), 1 << 2)
            local visible = imgui.begin_window("##wp_sub_p" .. p, nil, 1 | 32)
            if visible then
                -- Save rect for overlap detection (persists across frames)
                pcall(function()
                    local wpos = imgui.get_window_pos()
                    local wsz = imgui.get_window_size()
                    wp_submenu_rects[p] = { x = wpos.x, y = wpos.y, w = wsz.x, h = wsz.y }
                end)
                -- Build list of move sets (base + any stance variants in attack data)
                local move_sets = {}
                if char_name and char_name ~= "?" then
                    local cdata = wp_attack_data[char_name]
                    if cdata and cdata.moves then
                        move_sets[#move_sets + 1] = { name = char_name, moves = cdata.moves }
                    end
                    -- Find all variants: keys that start with the char name + "_"
                    local prefix = char_name:gsub("%-", "") .. "_"
                    for key, vdata in pairs(wp_attack_data) do
                        if key:sub(1, #prefix) == prefix and vdata.moves then
                            move_sets[#move_sets + 1] = { name = key, moves = vdata.moves }
                        end
                    end
                end

                if #move_sets > 0 then
                    -- Check All / Uncheck All across all sets
                    if imgui.button("Check All##p" .. p) then
                        for _, ms in ipairs(move_sets) do
                            for _, move in ipairs(ms.moves) do excl[move.input] = nil end
                        end
                        save_wp_filter()
                    end
                    imgui.same_line()
                    if imgui.button("Uncheck All##p" .. p) then
                        for _, ms in ipairs(move_sets) do
                            for _, move in ipairs(ms.moves) do excl[move.input] = true end
                        end
                        save_wp_filter()
                    end

                    for _, ms in ipairs(move_sets) do
                        imgui.spacing()
                        imgui.text(ms.name)
                        imgui.separator()
                        for _, move in ipairs(ms.moves) do
                            local is_checked = not excl[move.input]
                            local chg, val = imgui.checkbox(move.input .. "##p" .. p .. ms.name, is_checked)
                            if chg then
                                excl[move.input] = (not val) or nil
                                save_wp_filter()
                            end
                        end
                    end
                else
                    imgui.text("No opponent")
                    imgui.text("detected yet")
                end
            end
            imgui.end_window()
            imgui.pop_style_color(8)
        end
    end
end)

-- =========================================================
-- IMGUI MENU
-- =========================================================
re.on_draw_ui(function()
    if imgui.tree_node("Gameplay Stats Counter") then
        local changed, val = imgui.checkbox("Show Overlay", cfg.visible)
        if changed then cfg.visible = val end

        local dbg_chg, dbg_val = imgui.checkbox("Force Show in Training (debug)", cfg.debug_training)
        if dbg_chg then cfg.debug_training = dbg_val end

        imgui.text(is_in_replay and "Mode: REPLAY" or "Mode: --")

        local pp_chg, pp_val = imgui.checkbox("PP: PostGuard mode (trade_dm only)", cfg.pp_postguard_mode)
        if pp_chg then cfg.pp_postguard_mode = pp_val end

        imgui.spacing()

        if imgui.button("RESET ALL") then
            for p = 0, 1 do
                for _, k in ipairs(STATS) do counters[p][k] = 0 end
                counters[p].wp_ok = 0; counters[p].wp_opp = 0
                counters[p].hc_ok = 0; counters[p].hc_opp = 0
                counters[p].aa_ok = 0; counters[p].aa_opp = 0
                hc_state[p].monitor.active = false; hc_state[p].monitor.type = nil
                hc_state[p].monitor.has_reset_hs = false; hc_state[p].monitor.target_combo = 0
                hc_state[p].lockout = false
                track[p]._wp_tracking = false; track[p]._aa_opp_in_air = false
                track[p]._aa_opp_attacking = false; track[p]._aa_counted = false
            end
        end

        -- Show current counts
        for p = 0, 1 do
            imgui.text("--- P" .. (p+1) .. " ---")
            for _, k in ipairs(STATS) do
                imgui.text("  " .. FULL_LABELS[k] .. ": " .. counters[p][k])
            end
        end

        -- Live matrix debug - ALL fields
        imgui.spacing()
        imgui.text("--- MATRIX LIVE ---")
        imgui.text("Status: " .. matrix.debug_status)
        imgui.text(string.format("Head IDX: %d  |  Lists: %s", matrix.last_head, (matrix.p1_list and matrix.p2_list) and "OK" or "nil"))
        imgui.spacing()
        imgui.text("P1 item fields:")
        imgui.text(string.format("  FrameType=%d  Type=%d  Frame=%d  SF=%d  EF=%d  MainGauge=%d",
            matrix.p1_ft, matrix.p1_type or 0, matrix.p1_frame or 0, matrix.p1_sf or 0, matrix.p1_ef or 0, matrix.p1_gau))
        imgui.text(string.format("  dmg=%d  hs=%d  combo=%d  trade_dm=%s", matrix.p1_dmg or 0, matrix.p1_hs or 0, matrix.p1_combo or 0, tostring(matrix.p1_trade_dm)))
        imgui.text("P2 item fields:")
        imgui.text(string.format("  FrameType=%d  Type=%d  Frame=%d  SF=%d  EF=%d  MainGauge=%d",
            matrix.p2_ft, matrix.p2_type or 0, matrix.p2_frame or 0, matrix.p2_sf or 0, matrix.p2_ef or 0, matrix.p2_gau))
        imgui.text(string.format("  dmg=%d  hs=%d  combo=%d  trade_dm=%s", matrix.p2_dmg or 0, matrix.p2_hs or 0, matrix.p2_combo or 0, tostring(matrix.p2_trade_dm)))

        -- PP detection formula debug
        imgui.spacing()
        local mode_label = cfg.pp_postguard_mode and "PostGuard" or "Custom"
        imgui.text("--- PP DETECTION [" .. mode_label .. "] ---")
        for p = 0, 1 do
            local dm   = (p == 0) and matrix.p1_trade_dm or matrix.p2_trade_dm
            local dmg  = (p == 0) and (matrix.p1_dmg or 0) or (matrix.p2_dmg or 0)
            local hs   = (p == 0) and (matrix.p1_hs or 0) or (matrix.p2_hs or 0)
            local pcc  = (p == 0) and (matrix.p1_parry_combo or 0) or (matrix.p2_parry_combo or 0)
            local lock = track[p]._pp_locked and "LOCKED" or "READY"
            local not_normal = (pcc == 0)
            local result
            if cfg.pp_postguard_mode then
                result = (dm and not_normal) and ">>> PP!" or "no"
                imgui.text(string.format("P%d: trade_dm=%s  parry_combo=%d==0?  [%s] => %s",
                    p + 1, tostring(dm), pcc, lock, result))
            else
                result = (dm and not_normal and dmg == 34 and hs ~= 0) and ">>> PP!" or "no"
                imgui.text(string.format("P%d: trade_dm=%s  parry_combo=%d==0?  dmg=%d==34?  hs=%d!=0?  [%s] => %s",
                    p + 1, tostring(dm), pcc, dmg, hs, lock, result))
            end
        end

        imgui.tree_pop()
    end

    -- (WP submenu is drawn in re.on_frame, independent of REF menu)
end)

-- =========================================================
-- D2D DRAWING
-- =========================================================
local function d2d_init() end

local function d2d_draw()
    if not should_show() then return end

    local sw, sh = d2d.surface_size()

    -- Font sizing
    local fh = math.floor(sh * 0.016)
    local fhs = math.floor(sh * 0.013)
    if fh ~= _last_fh then
        _font = d2d.Font.new("Consolas", fh)
        _last_fh = fh
    end
    if fhs ~= _last_fhs then
        _font_small = d2d.Font.new("Consolas", fhs)
        _last_fhs = fhs
    end

    -- Layout
    local pw = sw * cfg.panel_width_pct
    local mx = sw * cfg.panel_margin_pct
    local py = sh * cfg.panel_y_pct
    local pad = sh * 0.008
    local row_h = fhs * 2.2
    local header_h = fh * 2.2
    local sep_h = 1
    local footer_h = fhs * 2.2
    local ph = header_h + sep_h + (#STATS * row_h) + pad

    for p = 0, 1 do
        -- Panel X position
        local px
        if p == 0 then
            px = mx  -- P1 left
        else
            px = sw - mx - pw  -- P2 right
        end

        -- Background
        d2d.fill_rect(px, py, pw, ph, COL.bg)
        d2d.outline_rect(px, py, pw, ph, 1, COL.border)

        -- Publish rect for DistanceViewer overlap detection
        if _G.FloatingRects then
            table.insert(_G.FloatingRects, { x = px, y = py, w = pw, h = ph })
            if wp_submenu_rects[p] then
                table.insert(_G.FloatingRects, wp_submenu_rects[p])
            end
        end

        -- Header
        d2d.fill_rect(px, py, pw, header_h, COL.header_bg)
        local header_col = p == 0 and COL.header_p1 or COL.header_p2
        local header_txt
        if p == 0 then
            header_txt = "  \xe2\x96\xb8 P1 STATS"
        else
            header_txt = "     P2 STATS \xe2\x97\x82"
        end

        local hx
        if p == 0 then
            hx = px + pad
        else
            -- Right-align header text for P2
            local approx_w = #"     P2 STATS .." * fh * 0.55
            hx = px + pw - pad - approx_w
        end
        local hy = py + (header_h - fh) * 0.5
        d2d.text(_font, header_txt, hx + 1, hy + 1, COL.shadow)
        d2d.text(_font, header_txt, hx, hy, header_col)

        -- RESET button in header
        local rst_txt = "RESET"
        local rst_w = #rst_txt * fhs * 0.62
        local rst_h = fhs * 1.4
        local rst_y = py + (header_h - rst_h) * 0.5
        local rst_x
        if p == 0 then
            rst_x = px + pw - pad - rst_w
        else
            rst_x = px + pad
        end
        if rst_flash[p] > 0 then rst_flash[p] = rst_flash[p] - 1 end
        local rst_col = rst_flash[p] > 0 and 0xFFFF4444 or COL.text_dim
        d2d.text(_font_small, rst_txt, rst_x + 1, rst_y + (rst_h - fhs) * 0.5 + 1, COL.shadow)
        d2d.text(_font_small, rst_txt, rst_x, rst_y + (rst_h - fhs) * 0.5, rst_col)
        rst_btn_screen[p].x = rst_x - fhs * 0.2
        rst_btn_screen[p].y = rst_y - fhs * 0.1
        rst_btn_screen[p].w = rst_w + fhs * 0.4
        rst_btn_screen[p].h = rst_h + fhs * 0.2

        -- Separator
        local sep_y = py + header_h
        d2d.fill_rect(px, sep_y, pw, sep_h, COL.separator)

        -- Stat rows
        local total = 0
        for i, k in ipairs(STATS) do
            local ry = sep_y + sep_h + (i - 1) * row_h
            local ty = ry + (row_h - fhs) * 0.5
            local val = counters[p][k]
            total = total + val

            local label = LABELS[k]
            -- WP/HC/AA show score + ratio, PP just count
            local val_str
            local ok_key = k .. "_ok"
            local opp_key = k .. "_opp"
            if counters[p][ok_key] and counters[p][opp_key] then
                local score = val
                local score_prefix = score >= 0 and "+" or ""
                val_str = score_prefix .. tostring(score) .. " (" .. tostring(counters[p][ok_key]) .. "/" .. tostring(counters[p][opp_key]) .. ")"
            else
                val_str = tostring(val)
            end
            local col = STAT_COLORS[k]

            if p == 0 then
                -- P1: label left, number right
                d2d.text(_font_small, label, px + pad + 1, ty + 1, COL.shadow)
                d2d.text(_font_small, label, px + pad, ty, col)

                -- ">" indicator next to WP label (clickable via imgui overlay)
                if k == "wp" then
                    local gt_x = px + pad + #label * fhs * 0.62 + fhs * 0.3
                    local gt_col = wp_submenu_open[0] and COL.text or COL.text_dim
                    d2d.text(_font_small, ">", gt_x + 1, ty + 1, COL.shadow)
                    d2d.text(_font_small, ">", gt_x, ty, gt_col)
                    wp_btn_screen[0].x = gt_x - fhs * 0.3
                    wp_btn_screen[0].y = ty - fhs * 0.3
                    wp_btn_screen[0].w = fhs * 1.5
                    wp_btn_screen[0].h = fhs * 1.8
                    wp_btn_screen[0].panel_x = px
                    wp_btn_screen[0].panel_w = pw
                end

                local vx = px + pw - pad - #val_str * fhs * 0.62
                d2d.text(_font_small, val_str, vx + 1, ty + 1, COL.shadow)
                d2d.text(_font_small, val_str, vx, ty, COL.text)
            else
                -- P2: number left, label right (mirrored)
                d2d.text(_font_small, val_str, px + pad + 1, ty + 1, COL.shadow)
                d2d.text(_font_small, val_str, px + pad, ty, COL.text)

                local lx = px + pw - pad - #label * fhs * 0.62
                d2d.text(_font_small, label, lx + 1, ty + 1, COL.shadow)
                d2d.text(_font_small, label, lx, ty, col)

                -- "<" indicator next to WP label (P2 side, before label)
                if k == "wp" then
                    local gt_x = lx - fhs * 0.9
                    local gt_col = wp_submenu_open[1] and COL.text or COL.text_dim
                    d2d.text(_font_small, "<", gt_x + 1, ty + 1, COL.shadow)
                    d2d.text(_font_small, "<", gt_x, ty, gt_col)
                    wp_btn_screen[1].x = gt_x - fhs * 0.3
                    wp_btn_screen[1].y = ty - fhs * 0.3
                    wp_btn_screen[1].w = fhs * 1.5
                    wp_btn_screen[1].h = fhs * 1.8
                    wp_btn_screen[1].panel_x = px
                    wp_btn_screen[1].panel_w = pw
                end
            end
        end
    end
end

if d2d and d2d.register then
    d2d.register(d2d_init, d2d_draw)
end
